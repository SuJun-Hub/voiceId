import json
import os
import pyaudio
import threading
import keyboard
import time
import ali_speech
from ali_speech.callbacks import SpeechRecognizerCallback
from ali_speech.constant import ASRFormat
from ali_speech.constant import ASRSampleRate
from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.request import CommonRequest
import configparser

"""pyaudio参数"""
CHUNK = 1024    # 数据包或者数据片段
FORMAT = pyaudio.paInt16    # pyaudio.paInt16表示我们使用量化位数 16位来进行录音
CHANNELS = 1    # 声道，1为单声道，2为双声道
RATE = 16000    # 采样率，每秒钟16000次

count = 1   # 计数
pre = True  # 是否准备开始录音
run = False  # 控制录音是否停止
timeSet=float(0.5)  #默认时间阈值
keySet="alt" #默认快捷键
keepStop=bool(True) #默认保留句号
resKey=bool(False) #是否再按一次按键恢复先前状态


"""
流程理解：
1.利用main函数前部建立与云端连接
    1. 计算设计好Token等参数
     config = configparser.ConfigParser()
    config.read_file(open('token.ini'))
    appkey = config.get("Token","appkey")
    2. 建立与阿里连接，用以调用回调函数
    client = ali_speech.NlsClient()
    client.set_log_level('WARNING') 
    3. 利用get_recognizer()函数设置回调接口
    recognizer = get_recognizer(client, appkey)
    p = pyaudio.PyAudio()
2. 设定按键钩子，等待按键触发
    keyboard.hook_key('alt', on_hotkey)
    print('{}//:按住键后开始说话...'.format(count), end=' ')
    keyboard.wait()
3. 触发按键，启动录音与上传
    1. 触发反应
    on_hotkey
    2. 启动录音流程
    process
    render
    3. 启动识别器
    ret = recognizer.start()
4. 启动识别器，云端返回消息，通过recognizer启动回调-回调函数
    on_started()
5. 按键结束，录音结束，识别器recognizer关闭，云端返回消息，结束回调-回调函数
    1. 识别器结束
    recognizer.close()
    2. 云端回调(若成功)
    on_completed()
    3. 回调函数读取数据，并进行处理打印


"""


class MyCallback(SpeechRecognizerCallback):
    """
    构造函数的参数没有要求，可根据需要设置添加
    示例中的name参数可作为待识别的音频文件名，用于在多线程中进行区分
    """
    def __init__(self, name='default'):
        self._name = name
    def on_started(self, message):
        #print('MyCallback.OnRecognitionStarted: %s' % message)
        pass
    def on_result_changed(self, message):
        print('任务信息: task_id: %s, result: %s' % (
            message['header']['task_id'], message['payload']['result']))
    def on_completed(self, message):
        print("****时间有效****")
        print("获取信息: %s" %time.time())
        print('结果: %s' % (
            message['payload']['result']))
        #print("结果时间: %s" %time.time())
        result = message['payload']['result']
        try:
            if not keepStop:
                if result[-1] == '。': # 如果最后一个符号是句号，就去掉。
                    result = result[0:-1]
        except Exception as e:
            pass
        print(result)
        global timeMea1, timeMea2, timeValue ,timeSet
        timeValue=timeMea2-timeMea1
        if timeValue>float(timeSet):
            keyboard.write(result) # 输入识别结果
            print("写入完成:%s" %time.time())
        print("时间差值: %f" %timeValue)
        if resKey:
            keyboard.press_and_release(keySet) # 再次按下按键，还原按键
    def on_task_failed(self, message):
        print('MyCallback.OnRecognitionTaskFailed: %s' % message)
    def on_channel_closed(self):
        print('MyCallback.OnRecognitionChannelClosed')
        pass

def get_token():

    config = configparser.ConfigParser()
    config.read_file(open('token.ini'))
    token = config.get("Token","Id")
    expireTime = config.get("Token","ExpireTime")
    accessID = config.get("Token","accessKeyId")
    accessKey = config.get("Token","accessKeySecret")
    # 要是 token 还有 5 秒过期，那就重新获得一个。
    if (int(expireTime) - time.time()) < 5 :
        # 创建AcsClient实例
        client = AcsClient(
        accessID, # 填写 AccessID
        accessKey, # 填写 AccessKey
        "cn-shanghai"
        );
        # 创建request，并设置参数
        request = CommonRequest()
        request.set_method('POST')
        request.set_domain('nls-meta.cn-shanghai.aliyuncs.com')
        request.set_version('2019-02-28')
        request.set_action_name('CreateToken')
        response = json.loads(client.do_action_with_exception(request))
        token = response['Token']['Id']
        expireTime = str(response['Token']['ExpireTime'])
        config.set('Token', 'Id', token)
        config.set('Token', 'ExpireTime', expireTime)
        config.write(open("token.ini", "w"))
        print
    return token

def get_recognizer(client, appkey):
    token = get_token()
    audio_name = 'none'
    callback = MyCallback(audio_name)
    recognizer = client.create_recognizer(callback)
    recognizer.set_appkey(appkey)
    recognizer.set_token(token)
    recognizer.set_format(ASRFormat.PCM)
    recognizer.set_sample_rate(ASRSampleRate.SAMPLE_RATE_16K)
    recognizer.set_enable_intermediate_result(False)
    recognizer.set_enable_punctuation_prediction(True)
    recognizer.set_enable_inverse_text_normalization(True)
    return(recognizer)

# 因为关闭 recognizer 有点慢，就须做成一个函数，用多线程关闭它。
def close_recognizer():
    global recognizer
    recognizer.close()

# 处理热键响应
def on_hotkey(event):
    global pre, run
    if event.event_type == "down":
        if pre and (not run):
            pre = False
            run = True
            threading.Thread(target=process).start()
        else:
            pass
    else:
        pre, run = True, False

# 处理是否开始录音
def process():
    global timeMea1
    timeMea1=time.time()
    print("响应录音: %s" %timeMea1)
    global run
    # 等待秒，如果 run 还是 True，就代表还没有松开大写键，是在长按状态，那么就可以开始识别。
    # 注释掉，直接开始录音
    """
    for i in range(4):
        if run:
            time.sleep(0.05)
        else:
            return
    """
    global count, recognizer, p, appkey
    threading.Thread(target=recoder,args=(recognizer, p)).start()      # 开始录音识别
    count += 1
    recognizer = get_recognizer(client, appkey) # 为下一次监听提前准备好 recognizer

# 录音识别处理
def recoder(recognizer, p):
    global run, timeMea2
    try:
        stream = p.open(channels=CHANNELS,
                format=FORMAT,
                rate=RATE,
                input=True,
                frames_per_buffer=CHUNK)
        #print('\r{}//:在听了，说完了请松开键...'.format(count), end=' ')
        ret = recognizer.start()
        print("开启识别: %s" %time.time())
        if ret < 0:
            return ret
        while run:
            data = stream.read(CHUNK)
            ret = recognizer.send(data)
            if ret < 0:
                break
        timeMea2=time.time()
        print("关闭识别: %s" %timeMea2)
        recognizer.stop()
        stream.stop_stream()
        stream.close()
        # p.terminate()
    except Exception as e:
        print(e)
    finally:
        threading.Thread(target=close_recognizer).start()    # 关闭 recognizer
    #print('{}//:按住键后开始说话...'.format(count), end=' ')



if __name__ == '__main__':

    print('\r\n开始程序\r\n')
    print("开始时间: %s" %time.time())


    #读取基础设置voiceSet中的时间阈值与使用按键
    if not os.path.exists('voiceSet.ini'):
        voice_set="""0.3
alt
True
False"""
        fp = open("voiceSet.ini",'w')
        fp.write(voice_set)
        fp.close()
    fvp=open("voiceSet.ini",'r')
    fvpl=fvp.readlines()
    fvp.close()
    timeSet=fvpl[0]
    keySet=fvpl[1].strip()
    keepStop=bool(fvpl[2])
    resKey=bool(fvpl[3])
    #print(timeSet,keySet)


    if not os.path.exists('token.ini'):
        init_id = """[Token]
id = 0000000000000000000
expiretime = 0000000000
accessKeyId = 000000
accessKeySecret = 000000
appkey = 00000"""
        fp = open("token.ini",'w')
        fp.write(init_id)
        fp.close()
        input("""\r\n        检测到没有配置文件，所以刚刚已在同级目录生成了 token.ini 配置文件，\r\n
        请打开 token.ini 配置文件，\r\n
        然后填入阿里云的 accesskeyid 和 accesskeysecret, 以及你的语音识别项目的 appkey，\r\n
        再回到本界面，按任意键后，回车继续\r\n
        
        如果下面出错了，那么就很有可能是 accesskeyid 、accesskeysecret 或 appkey 填错了\r\n""")
    config = configparser.ConfigParser()
    config.read_file(open('token.ini'))
    appkey = config.get("Token","appkey")
    
    client = ali_speech.NlsClient()
    client.set_log_level('WARNING') # 设置 client 输出日志信息的级别：DEBUG、INFO、WARNING、ERROR
    
    recognizer = get_recognizer(client, appkey)
    p = pyaudio.PyAudio()
    
    #print("""\r\n初始化完成，现在可以将本工具最小化，在需要输入的界面，按住键开始说话，松开键后识别结果会自动输入\r\n""")
    
    keyboard.hook_key(keySet, on_hotkey)
    #print('{}//:按住键后开始说话...'.format(count), end=' ')   
    print("配置时间: %s" %time.time())
    keyboard.wait()
